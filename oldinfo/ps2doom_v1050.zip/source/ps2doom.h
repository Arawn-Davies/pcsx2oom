#ifndef _PS2DOOM_H_
#define _PS2DOOM_H_

#include <tcpip.h>



int gethostname(char *name, int len);
u32 inet_addr(const char *cp);

float pow(float a, float b);

// void setbuf ( FILE * stream, char * buffer );

#endif

